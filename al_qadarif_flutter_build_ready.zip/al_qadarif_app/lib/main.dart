import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

const green = Color(0xFF075B3A);
const gold = Color(0xFFD9A520);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = PlaceStore();
  await store.load();
  runApp(QadarifApp(store: store));
}

class QadarifApp extends StatelessWidget {
  final PlaceStore store;
  const QadarifApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'القضارف',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF7F9F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: green,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          margin: const EdgeInsets.all(8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: HomePage(store: store),
    );
  }
}

class Place {
  String id, name, category, area, phone, description, imagePath, lat, lng;
  bool favorite;

  Place({
    required this.id,
    required this.name,
    required this.category,
    this.area = '',
    this.phone = '',
    this.description = '',
    this.imagePath = '',
    this.lat = '',
    this.lng = '',
    this.favorite = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'category': category, 'area': area,
    'phone': phone, 'description': description, 'imagePath': imagePath,
    'lat': lat, 'lng': lng, 'favorite': favorite,
  };

  factory Place.fromJson(Map<String, dynamic> j) => Place(
    id: j['id'] ?? '',
    name: j['name'] ?? '',
    category: j['category'] ?? 'خدمات',
    area: j['area'] ?? '',
    phone: j['phone'] ?? '',
    description: j['description'] ?? '',
    imagePath: j['imagePath'] ?? '',
    lat: j['lat'] ?? '',
    lng: j['lng'] ?? '',
    favorite: j['favorite'] ?? false,
  );
}

class PlaceStore extends ChangeNotifier {
  final List<Place> places = [];
  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString('places');
    if (raw != null) {
      places
        ..clear()
        ..addAll((jsonDecode(raw) as List).map((e) => Place.fromJson(e)));
    } else {
      places.addAll([
        Place(id: '1', name: 'أضف أول مكان', category: 'أماكن حيوية',
          area: 'القضارف', description: 'هذه بيانات تجريبية. من الإدارة يمكنك إضافة الأماكن الحقيقية.'),
      ]);
    }
    notifyListeners();
  }

  Future<void> save() async {
    await _prefs?.setString('places', jsonEncode(places.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> add(Place p) async {
    places.insert(0, p);
    await save();
  }

  Future<void> remove(Place p) async {
    places.remove(p);
    await save();
  }

  Future<void> toggleFavorite(Place p) async {
    p.favorite = !p.favorite;
    await save();
  }
}

final categories = <Map<String, dynamic>>[
  {'name': 'فنادق', 'icon': Icons.hotel},
  {'name': 'مطاعم وكافيهات', 'icon': Icons.restaurant},
  {'name': 'صحة', 'icon': Icons.local_hospital},
  {'name': 'أسواق ومحلات', 'icon': Icons.shopping_bag},
  {'name': 'محطات وقود', 'icon': Icons.local_gas_station},
  {'name': 'بنوك وصرافات', 'icon': Icons.account_balance},
  {'name': 'مواصلات', 'icon': Icons.directions_car},
  {'name': 'خدمات', 'icon': Icons.handyman},
  {'name': 'أماكن حكومية', 'icon': Icons.account_balance},
  {'name': 'أماكن حيوية وسياحية', 'icon': Icons.place},
];

class HomePage extends StatefulWidget {
  final PlaceStore store;
  const HomePage({super.key, required this.store});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';

  @override
  Widget build(BuildContext context) {
    final body = tab == 0 ? _home() :
      tab == 1 ? MapPage(store: widget.store) :
      tab == 2 ? FavoritesPage(store: widget.store) :
      MorePage(store: widget.store);

    return Scaffold(
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'الخريطة'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
        ],
      ),
    );
  }

  Widget _home() {
    final filtered = widget.store.places.where((p) =>
      query.isEmpty || p.name.contains(query) || p.category.contains(query) || p.area.contains(query)
    ).take(10).toList();

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _hero()),
          SliverToBoxAdapter(child: _search()),
          SliverToBoxAdapter(child: const Padding(
            padding: EdgeInsets.fromLTRB(18, 18, 18, 8),
            child: Text('استكشف القضارف', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green)),
          )),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            sliver: SliverGrid.count(
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: .83,
              children: categories.map((c) => _category(c)).toList(),
            ),
          ),
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('الأماكن المضافة', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              TextButton(onPressed: () => setState(() => query = ''), child: const Text('عرض الكل')),
            ]),
          )),
          filtered.isEmpty
            ? const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد نتائج'))))
            : SliverList(delegate: SliverChildBuilderDelegate(
                (context, i) => PlaceCard(place: filtered[i], store: widget.store),
                childCount: filtered.length,
              )),
        ],
      ),
    );
  }

  Widget _hero() => Container(
    padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
    decoration: const BoxDecoration(
      gradient: LinearGradient(colors: [Color(0xFF064D32), green]),
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        const Icon(Icons.location_on, color: gold, size: 34),
        const SizedBox(width: 8),
        const Expanded(child: Text('القضارف', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800))),
        IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddPlacePage(store: widget.store))), icon: const Icon(Icons.add_business, color: Colors.white)),
      ]),
      const Text('دليل الولاية', style: TextStyle(color: gold, fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('كل الأماكن .. كل الخدمات .. في تطبيق واحد', style: TextStyle(color: Colors.white70)),
    ]),
  );

  Widget _search() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
    child: TextField(
      onChanged: (v) => setState(() => query = v),
      decoration: InputDecoration(
        hintText: 'ابحث عن فندق، مطعم، خدمة...',
        prefixIcon: const Icon(Icons.search, color: green),
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
      ),
    ),
  );

  Widget _category(Map<String, dynamic> c) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: () => setState(() => query = c['name']),
    child: Card(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      CircleAvatar(radius: 24, backgroundColor: const Color(0xFFEAF4EE), child: Icon(c['icon'], color: green)),
      const SizedBox(height: 7),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: Text(c['name'], textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600))),
    ])),
  );
}

class PlaceCard extends StatelessWidget {
  final Place place; final PlaceStore store;
  const PlaceCard({super.key, required this.place, required this.store});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.all(10),
      leading: _thumb(),
      title: Text(place.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${place.category}  •  ${place.area}'),
      trailing: IconButton(
        icon: Icon(place.favorite ? Icons.favorite : Icons.favorite_border, color: place.favorite ? Colors.red : Colors.grey),
        onPressed: () => store.toggleFavorite(place),
      ),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlaceDetails(place: place, store: store))),
    ),
  );

  Widget _thumb() {
    if (place.imagePath.isNotEmpty && File(place.imagePath).existsSync()) {
      return ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(place.imagePath), width: 68, height: 68, fit: BoxFit.cover));
    }
    return Container(width: 68, height: 68, decoration: BoxDecoration(color: const Color(0xFFEAF4EE), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.place, color: green, size: 32));
  }
}

class PlaceDetails extends StatelessWidget {
  final Place place; final PlaceStore store;
  const PlaceDetails({super.key, required this.place, required this.store});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تفاصيل المكان')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      if (place.imagePath.isNotEmpty && File(place.imagePath).existsSync())
        ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.file(File(place.imagePath), height: 210, fit: BoxFit.cover)),
      const SizedBox(height: 16),
      Text(place.name, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: green)),
      Text(place.category, style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (place.area.isNotEmpty) _info(Icons.location_on, place.area),
      if (place.phone.isNotEmpty) _info(Icons.phone, place.phone),
      if (place.description.isNotEmpty) _info(Icons.info_outline, place.description),
      const SizedBox(height: 15),
      Row(children: [
        if (place.phone.isNotEmpty) Expanded(child: FilledButton.icon(onPressed: () => launchUrl(Uri.parse('tel:${place.phone}')), icon: const Icon(Icons.call), label: const Text('اتصال'))),
        if (place.lat.isNotEmpty && place.lng.isNotEmpty) ...[
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () async {
            final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${place.lat},${place.lng}');
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }, icon: const Icon(Icons.directions), label: const Text('الاتجاهات'))),
        ]
      ]),
    ]),
  );

  Widget _info(IconData icon, String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: green), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
    ]),
  );
}

class AddPlacePage extends StatefulWidget {
  final PlaceStore store;
  const AddPlacePage({super.key, required this.store});
  @override State<AddPlacePage> createState() => _AddPlacePageState();
}

class _AddPlacePageState extends State<AddPlacePage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController(), area = TextEditingController(), phone = TextEditingController(),
      description = TextEditingController(), lat = TextEditingController(), lng = TextEditingController();
  String category = categories.first['name'];
  String imagePath = '';

  Future<void> pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (x != null) setState(() => imagePath = x.path);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة مكان أو خدمة')),
    body: Form(
      key: formKey,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        InkWell(onTap: pickImage, child: Container(
          height: 150, decoration: BoxDecoration(color: const Color(0xFFEAF4EE), borderRadius: BorderRadius.circular(20)),
          child: imagePath.isEmpty ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo, size: 42, color: green), Text('أضف صورة للمكان')])
            : ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.file(File(imagePath), fit: BoxFit.cover)),
        )),
        const SizedBox(height: 15),
        TextFormField(controller: name, decoration: const InputDecoration(labelText: 'اسم المكان *'), validator: (v) => v!.trim().isEmpty ? 'اكتب اسم المكان' : null),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'التصنيف'), items: categories.map((c) => DropdownMenuItem(value: c['name'] as String, child: Text(c['name'] as String))).toList(), onChanged: (v) => setState(() => category = v!)),
        const SizedBox(height: 10),
        TextFormField(controller: area, decoration: const InputDecoration(labelText: 'المنطقة / الحي')),
        const SizedBox(height: 10),
        TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
        const SizedBox(height: 10),
        TextFormField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف المكان')),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: TextFormField(controller: lat, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'خط العرض Latitude'))),
          const SizedBox(width: 10),
          Expanded(child: TextFormField(controller: lng, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'خط الطول Longitude'))),
        ]),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: () async {
            if (!formKey.currentState!.validate()) return;
            await widget.store.add(Place(
              id: DateTime.now().microsecondsSinceEpoch.toString(),
              name: name.text.trim(), category: category, area: area.text.trim(),
              phone: phone.text.trim(), description: description.text.trim(),
              imagePath: imagePath, lat: lat.text.trim(), lng: lng.text.trim(),
            ));
            if (context.mounted) Navigator.pop(context);
          },
          icon: const Icon(Icons.save), label: const Text('حفظ المكان'),
        ),
      ]),
    ),
  );
}

class FavoritesPage extends StatelessWidget {
  final PlaceStore store;
  const FavoritesPage({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final list = store.places.where((p) => p.favorite).toList();
    return Scaffold(appBar: AppBar(title: const Text('المفضلة')), body: list.isEmpty
      ? const Center(child: Text('ما عندك أماكن مفضلة حالياً'))
      : ListView(children: list.map((p) => PlaceCard(place: p, store: store)).toList()));
  }
}

class MapPage extends StatelessWidget {
  final PlaceStore store;
  const MapPage({super.key, required this.store});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('خريطة الأماكن')),
    body: Center(child: Padding(padding: const EdgeInsets.all(25), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.map, size: 90, color: green),
      const SizedBox(height: 15),
      const Text('الخريطة جاهزة للربط بخرائط Google أو Mapbox.', textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=القضارف'), mode: LaunchMode.externalApplication), icon: const Icon(Icons.open_in_new), label: const Text('فتح القضارف في Google Maps')),
    ]))),
  );
}

class MorePage extends StatelessWidget {
  final PlaceStore store;
  const MorePage({super.key, required this.store});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المزيد')),
    body: ListView(children: [
      const ListTile(leading: Icon(Icons.info_outline, color: green), title: Text('عن التطبيق'), subtitle: Text('القضارف | دليل الولاية')),
      ListTile(leading: const Icon(Icons.add_business, color: green), title: const Text('إضافة مكان أو خدمة'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddPlacePage(store: store)))),
      const ListTile(leading: Icon(Icons.privacy_tip_outlined, color: green), title: Text('الخصوصية'), subtitle: Text('سياسة الخصوصية ستضاف قبل النشر على Google Play')),
    ]),
  );
}
